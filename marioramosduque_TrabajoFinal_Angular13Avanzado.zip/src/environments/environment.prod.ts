export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyDLeE1U0xbNxCfJQAUoH_UcXofzi4kRtKU",
    authDomain: "chat-e884d.firebaseapp.com",
    databaseURL: "https://chat-e884d-default-rtdb.europe-west1.firebasedatabase.app",
    projectId: "chat-e884d",
    storageBucket: "chat-e884d.appspot.com",
    messagingSenderId: "109311955521",
    appId: "1:109311955521:web:52f16c302a304f2be9acc0"
  }
};
